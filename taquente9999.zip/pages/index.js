import Head from 'next/head';
import Image from 'next/image';

export default function Home() {
  return (
    <>
      <Head>
        <title>TáQuente!</title>
        <meta name="description" content="TáQuente! - Comida gostosa e quente sempre!" />
      </Head>
      <main style={{ textAlign: 'center', padding: '2rem' }}>
        <Image src="/logo.jpg" alt="Logo TáQuente" width={200} height={200} />
        <h1>TáQuente!</h1>
        <p>Comida gostosa e quente sempre!</p>
      </main>
    </>
  );
}