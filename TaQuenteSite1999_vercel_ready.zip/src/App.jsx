function App() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-red-500 text-white text-4xl font-bold">
      TáQuente! Site funcionando com Vite + React + Tailwind!
    </div>
  )
}

export default App